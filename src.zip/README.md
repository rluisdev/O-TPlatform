# Order & trade platform

- node version - 18
- `npm install`
- /server `npm install`
- /server `node backend.js`
- `npm run dev`
- `http://localhost:5173`
