export interface WebSocketContextType {
  ws: WebSocket | null;
  connected: boolean;
}
